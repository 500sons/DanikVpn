# DanikVpn v2.1.0 — AmneziaWG 2.0 Android Client

Сборка с обновлённым компилятором Kotlin 2.1.21 + Compose Compiler plugin и `-Xskip-metadata-version-check`, полностью совместимая с метаданными Kotlin 2.2.21 из библиотеки `amneziawg-android:2.3.3`.
