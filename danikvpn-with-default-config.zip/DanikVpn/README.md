# DanikVpn v2.0.1 — AmneziaWG 2.0 Android Client

Исправлен конфликт AAR-метаданных (`androidx.core:1.17.0` -> принудительно `1.13.1`), полная совместимость с AGP 8.5.2, Gradle 8.7 и compileSdk 34.
