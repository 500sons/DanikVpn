# DanikVpn — Android VPN-клиент (AmneziaWG 2.0 + GitHub Actions)

Готовый Android-проект на **Kotlin + Jetpack Compose (Material 3)** с уже вшитым конфигом **AmneziaWG (`US-FREE#82`, `146.70.230.82:88`)** по умолчанию и автоматической сборкой `.apk` через **GitHub Actions**.

## Что вшито по умолчанию
- Конфиг сохранён в `app/src/main/assets/default_awg.conf` и автоматически загружается при первом запуске приложения.
- Парсер `ConfigParser.kt` поддерживает все параметры из вашего конфига: `S1–S4`, `Jc`, `Jmin`, `Jmax`, `H1–H4`, `I1` (CPS-сигнатуру), IPv4 + IPv6 адреса (`10.2.0.2/32, 2a07:b944::2:2/128`) и DNS (`10.2.0.1, 2a07:b944::2:1`).

## Как собрать APK через GitHub Actions
1. Загрузите распакованную папку `DanikVpn` в репозиторий на GitHub.
2. Откройте вкладку **Actions** → **Build DanikVpn APK** → **Run workflow**.
3. Скачайте готовый APK из раздела **Artifacts** (`DanikVpn-debug-apk` или `DanikVpn-release-apk`).
