# DanikVpn v2.0 — AmneziaWG 2.0 Android Client

Собран на готовой официальной библиотеке **AmneziaWG 2.0 (`com.zaneschepke:amneziawg-android:2.3.3`)** с предустановленным ядром `libwg-go.so` внутри AAR — собирается в GitHub Actions без CMake, NDK и Go.
