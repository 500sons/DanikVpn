# DanikVpn — Android VPN с нативным ядром AmneziaWG 2.0

Полностью рабочий VPN-клиент на Kotlin + Jetpack Compose с реальным ядром **amneziawg-go** (`libwg-go.so`), скрытым встроенным конфигом, переключением протоколов и поддержкой подписок.
