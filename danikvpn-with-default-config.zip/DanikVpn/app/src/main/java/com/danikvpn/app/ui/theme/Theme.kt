package com.danikvpn.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val BananaYellow = Color(0xFFFFD60A)
val BananaGold = Color(0xFFFFB703)
val ObsidianBg = Color(0xFF0D0F14)
val CardDark = Color(0xFF161A23)
val CardElevated = Color(0xFF1E2430)
val ConnectedGreen = Color(0xFF2EE59D)
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)

private val DanikDarkColorScheme = darkColorScheme(
    primary = BananaYellow,
    onPrimary = Color(0xFF111318),
    secondary = BananaGold,
    background = ObsidianBg,
    surface = CardDark,
    surfaceVariant = CardElevated,
    onBackground = TextPrimary,
    onSurface = TextPrimary,
    onSurfaceVariant = TextSecondary
)

@Composable
fun DanikVpnTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DanikDarkColorScheme,
        content = content
    )
}
