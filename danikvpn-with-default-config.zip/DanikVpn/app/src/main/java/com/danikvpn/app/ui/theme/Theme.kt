package com.danikvpn.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val BananaYellow = Color(0xFFFFD60A)
val BananaGold = Color(0xFFFFAA00)
val ObsidianBg = Color(0xFF090B10)
val CardDark = Color(0xFF121621)
val CardElevated = Color(0xFF1A2030)
val ConnectedGreen = Color(0xFF2EE59D)
val CyanGlow = Color(0xFF38BDF8)
val DangerRed = Color(0xFFFF5C5C)
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)

private val DanikDarkColorScheme = darkColorScheme(
    primary = BananaYellow,
    onPrimary = Color(0xFF090B10),
    secondary = BananaGold,
    background = ObsidianBg,
    surface = CardDark,
    surfaceVariant = CardElevated,
    onBackground = TextPrimary,
    onSurface = TextPrimary,
    onSurfaceVariant = TextSecondary
)

@Composable
fun DanikVpnTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DanikDarkColorScheme,
        content = content
    )
}
