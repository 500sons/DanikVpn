package com.danikvpn.app.vpn

import android.content.Context
import android.content.Intent
import com.danikvpn.app.model.ConnectionState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.amnezia.awg.backend.GoBackend
import org.amnezia.awg.backend.Tunnel
import org.amnezia.awg.config.Config
import java.io.BufferedReader
import java.io.StringReader

object DanikTunnelManager {

    private var backend: GoBackend? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var statsJob: Job? = null

    private val _connectionState = MutableStateFlow(ConnectionState.DISCONNECTED)
    val connectionState = _connectionState.asStateFlow()

    private val _rxBytes = MutableStateFlow(0L)
    val rxBytes = _rxBytes.asStateFlow()

    private val _txBytes = MutableStateFlow(0L)
    val txBytes = _txBytes.asStateFlow()

    private val _rxSpeedBps = MutableStateFlow(0L)
    val rxSpeedBps = _rxSpeedBps.asStateFlow()

    private val _txSpeedBps = MutableStateFlow(0L)
    val txSpeedBps = _txSpeedBps.asStateFlow()

    private val _speedHistory = MutableStateFlow<List<Float>>(List(24) { 0f })
    val speedHistory = _speedHistory.asStateFlow()

    private val _lastError = MutableStateFlow<String?>(null)
    val lastError = _lastError.asStateFlow()

    private val _statusLog = MutableStateFlow("Ядро AmneziaWG 2.0 готово к запуску")
    val statusLog = _statusLog.asStateFlow()

    private val danikTunnel = object : Tunnel {
        override fun getName(): String = "DanikVpn"
        override fun onStateChange(newState: Tunnel.State) {
            _connectionState.value = when (newState) {
                Tunnel.State.UP -> ConnectionState.CONNECTED
                Tunnel.State.DOWN -> ConnectionState.DISCONNECTED
                Tunnel.State.TOGGLE -> ConnectionState.CONNECTING
            }
        }
    }

    private fun getBackend(context: Context): GoBackend {
        return backend ?: GoBackend(context.applicationContext).also { backend = it }
    }

    fun prepareVpnIntent(context: Context): Intent? {
        return GoBackend.VpnService.prepare(context)
    }

    fun connect(context: Context, rawConfig: String, serverLabel: String) {
        scope.launch {
            try {
                _lastError.value = null
                _connectionState.value = ConnectionState.CONNECTING
                _statusLog.value = "Инициализация AmneziaWG 2.0 ($serverLabel)..."

                val parsedConfig = Config.parse(BufferedReader(StringReader(rawConfig)))
                val goBackend = getBackend(context)

                // Ensure clean start
                try {
                    if (goBackend.getState(danikTunnel) == Tunnel.State.UP) {
                        goBackend.setState(danikTunnel, Tunnel.State.DOWN, null)
                    }
                } catch (_: Exception) {
                }

                goBackend.setState(danikTunnel, Tunnel.State.UP, parsedConfig)
                _connectionState.value = ConnectionState.CONNECTED
                _statusLog.value = "Туннель активен • $serverLabel"
                startStatsLoop(goBackend)
            } catch (e: Exception) {
                _connectionState.value = ConnectionState.DISCONNECTED
                val msg = e.localizedMessage ?: e.javaClass.simpleName
                _lastError.value = "Ошибка подключения: $msg"
                _statusLog.value = "Ошибка: $msg"
                stopStatsLoop()
            }
        }
    }

    fun disconnect(context: Context) {
        scope.launch {
            try {
                stopStatsLoop()
                val goBackend = getBackend(context)
                goBackend.setState(danikTunnel, Tunnel.State.DOWN, null)
            } catch (_: Exception) {
            } finally {
                _connectionState.value = ConnectionState.DISCONNECTED
                _rxSpeedBps.value = 0L
                _txSpeedBps.value = 0L
                _speedHistory.value = List(24) { 0f }
                _statusLog.value = "Отключено"
            }
        }
    }

    private fun startStatsLoop(goBackend: GoBackend) {
        statsJob?.cancel()
        var prevRx = 0L
        var prevTx = 0L

        statsJob = scope.launch {
            while (isActive && _connectionState.value == ConnectionState.CONNECTED) {
                try {
                    val stats = goBackend.getStatistics(danikTunnel)
                    val curRx = stats.totalRx()
                    val curTx = stats.totalTx()

                    val dRx = (curRx - prevRx).coerceAtLeast(0L)
                    val dTx = (curTx - prevTx).coerceAtLeast(0L)
                    prevRx = curRx
                    prevTx = curTx

                    _rxBytes.value = curRx
                    _txBytes.value = curTx
                    _rxSpeedBps.value = dRx
                    _txSpeedBps.value = dTx

                    val kbPerSec = (dRx + dTx) / 1024f
                    val nextList = (_speedHistory.value.drop(1) + kbPerSec)
                    _speedHistory.value = nextList
                } catch (_: Exception) {
                }
                delay(1000L)
            }
        }
    }

    private fun stopStatsLoop() {
        statsJob?.cancel()
        statsJob = null
    }
}
