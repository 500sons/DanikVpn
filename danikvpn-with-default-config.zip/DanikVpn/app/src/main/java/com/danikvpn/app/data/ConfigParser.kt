package com.danikvpn.app.data

import android.util.Base64
import com.danikvpn.app.model.AmneziaWgConfig
import com.danikvpn.app.model.ServerNode
import com.danikvpn.app.model.VpnProtocol
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

object ConfigParser {

    fun parseAmneziaWg(raw: String): AmneziaWgConfig {
        var serverLabel = ""
        var privateKey = ""
        var address = "10.2.0.2/32"
        var dns = "10.2.0.1"
        var mtu = 1420
        var jc = 3
        var jmin = 1
        var jmax = 3
        var s1 = 0
        var s2 = 0
        var s3 = 0
        var s4 = 0
        var h1 = "1"
        var h2 = "2"
        var h3 = "3"
        var h4 = "4"
        var i1 = ""
        var i2 = ""
        var i3 = ""
        var i4 = ""
        var i5 = ""

        var publicKey = ""
        var presharedKey = ""
        var endpoint = ""
        var allowedIps = "0.0.0.0/0, ::/0"
        var keepalive = 25

        raw.lines().forEach { line ->
            val trimmedLine = line.trim()
            if (trimmedLine.startsWith("#")) {
                val comment = trimmedLine.removePrefix("#").trim()
                if (comment.startsWith("Server:", ignoreCase = true)) {
                    serverLabel = comment.substringAfter(":").trim()
                }
            }
            val clean = trimmedLine.substringBefore("#").trim()
            if (clean.contains("=")) {
                val key = clean.substringBefore("=").trim().lowercase()
                val value = clean.substringAfter("=").trim()
                when (key) {
                    "privatekey" -> privateKey = value
                    "address" -> address = value
                    "dns" -> dns = value
                    "mtu" -> mtu = value.toIntOrNull() ?: mtu
                    "jc" -> jc = value.toIntOrNull() ?: jc
                    "jmin" -> jmin = value.toIntOrNull() ?: jmin
                    "jmax" -> jmax = value.toIntOrNull() ?: jmax
                    "s1" -> s1 = value.toIntOrNull() ?: s1
                    "s2" -> s2 = value.toIntOrNull() ?: s2
                    "s3" -> s3 = value.toIntOrNull() ?: s3
                    "s4" -> s4 = value.toIntOrNull() ?: s4
                    "h1" -> h1 = value
                    "h2" -> h2 = value
                    "h3" -> h3 = value
                    "h4" -> h4 = value
                    "i1" -> i1 = value
                    "i2" -> i2 = value
                    "i3" -> i3 = value
                    "i4" -> i4 = value
                    "i5" -> i5 = value
                    "publickey" -> publicKey = value
                    "presharedkey" -> presharedKey = value
                    "endpoint" -> endpoint = value
                    "allowedips" -> allowedIps = value
                    "persistentkeepalive" -> keepalive = value.toIntOrNull() ?: keepalive
                }
            }
        }

        return AmneziaWgConfig(
            serverLabel = serverLabel,
            privateKey = privateKey,
            address = address,
            dns = dns,
            mtu = mtu,
            jc = jc,
            jmin = jmin,
            jmax = jmax,
            s1 = s1,
            s2 = s2,
            s3 = s3,
            s4 = s4,
            h1 = h1,
            h2 = h2,
            h3 = h3,
            h4 = h4,
            i1 = i1,
            i2 = i2,
            i3 = i3,
            i4 = i4,
            i5 = i5,
            publicKey = publicKey,
            presharedKey = presharedKey,
            endpoint = endpoint,
            allowedIps = allowedIps,
            persistentKeepalive = keepalive,
            rawText = raw
        )
    }

    fun buildServerFromConfig(name: String, raw: String, source: String? = null): ServerNode {
        val trimmed = raw.trim()
        return when {
            trimmed.startsWith("vless://", ignoreCase = true) -> {
                val label = trimmed.substringAfter("#", name).ifBlank { name }
                ServerNode(
                    name = java.net.URLDecoder.decode(label, "UTF-8"),
                    countryCode = "VLESS",
                    subtitle = "Узел из подписки",
                    pingMs = Random.nextInt(24, 65),
                    protocol = VpnProtocol.VLESS_REALITY,
                    rawConfig = trimmed,
                    subscriptionSource = source
                )
            }
            trimmed.startsWith("awg://", ignoreCase = true) -> {
                val decoded = tryDecodeBase64(trimmed.removePrefix("awg://").substringBefore("#"))
                val parsed = parseAmneziaWg(decoded)
                val label = trimmed.substringAfter("#", parsed.serverLabel.ifBlank { name }).ifBlank { name }
                ServerNode(
                    name = label,
                    countryCode = "AWG",
                    subtitle = "Узел из подписки",
                    pingMs = Random.nextInt(19, 55),
                    protocol = VpnProtocol.AMNEZIA_WG,
                    rawConfig = decoded,
                    subscriptionSource = source
                )
            }
            else -> {
                val parsed = parseAmneziaWg(trimmed)
                val hasAwgParams = trimmed.contains("Jc", ignoreCase = true) ||
                    trimmed.contains("H1", ignoreCase = true) ||
                    trimmed.contains("I1", ignoreCase = true)
                val resolvedName = parsed.serverLabel.ifBlank { name.ifBlank { "Сервер подписки" } }
                val countryBadge = when {
                    resolvedName.startsWith("US", ignoreCase = true) -> "US"
                    resolvedName.startsWith("NL", ignoreCase = true) -> "NL"
                    resolvedName.startsWith("DE", ignoreCase = true) -> "DE"
                    hasAwgParams -> "AWG"
                    else -> "WG"
                }
                ServerNode(
                    name = resolvedName,
                    countryCode = countryBadge,
                    subtitle = "Защищённый канал",
                    pingMs = Random.nextInt(22, 48),
                    protocol = if (hasAwgParams) VpnProtocol.AMNEZIA_WG else VpnProtocol.WIREGUARD,
                    rawConfig = trimmed,
                    subscriptionSource = source
                )
            }
        }
    }

    fun fetchSubscription(subUrl: String): List<ServerNode> {
        val connection = (URL(subUrl.trim()).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 8000
            readTimeout = 8000
            setRequestProperty("User-Agent", "DanikVpn/1.2 (HappCompatible)")
        }

        val body = connection.inputStream.bufferedReader().use { it.readText() }.trim()
        connection.disconnect()

        val decoded = if (body.contains("[Interface]") || body.contains("://")) {
            body
        } else {
            tryDecodeBase64(body)
        }

        val result = mutableListOf<ServerNode>()
        if (decoded.contains("[Interface]")) {
            result.add(buildServerFromConfig("Сервер подписки", decoded, subUrl))
        } else {
            decoded.lines()
                .map { it.trim() }
                .filter { it.isNotEmpty() && !it.startsWith("#") }
                .forEachIndexed { index, line ->
                    result.add(buildServerFromConfig("Сервер #${index + 1}", line, subUrl))
                }
        }
        return result
    }

    fun currentTimeFormatted(): String {
        return SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(Date())
    }

    private fun tryDecodeBase64(input: String): String {
        return try {
            val normalized = input.replace('-', '+').replace('_', '/')
            String(Base64.decode(normalized, Base64.DEFAULT), Charsets.UTF_8)
        } catch (_: Exception) {
            input
        }
    }
}
