package com.danikvpn.app

import android.app.Activity
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.danikvpn.app.data.ConfigManager
import com.danikvpn.app.model.ConnectionState
import com.danikvpn.app.model.DnsPreset
import com.danikvpn.app.model.ServerNode
import com.danikvpn.app.model.SubscriptionItem
import com.danikvpn.app.model.VpnProtocol
import com.danikvpn.app.ui.theme.*
import com.danikvpn.app.vpn.DanikTunnelManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val hiddenDefaultConfig = ConfigManager.loadHiddenDefaultConfig(this)

        setContent {
            DanikVpnTheme {
                DanikVpnApp(builtInDefaultConfig = hiddenDefaultConfig)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DanikVpnApp(builtInDefaultConfig: String) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val connectionState by DanikTunnelManager.connectionState.collectAsState()
    val rxBytes by DanikTunnelManager.rxBytes.collectAsState()
    val txBytes by DanikTunnelManager.txBytes.collectAsState()
    val rxSpeed by DanikTunnelManager.rxSpeedBps.collectAsState()
    val txSpeed by DanikTunnelManager.txSpeedBps.collectAsState()
    val speedHistory by DanikTunnelManager.speedHistory.collectAsState()
    val lastError by DanikTunnelManager.lastError.collectAsState()
    val statusLog by DanikTunnelManager.statusLog.collectAsState()

    LaunchedEffect(lastError) {
        if (!lastError.isNullOrBlank()) {
            Toast.makeText(context, lastError, Toast.LENGTH_LONG).show()
        }
    }

    var selectedTab by remember { mutableIntStateOf(0) }
    var selectedProtocol by remember { mutableStateOf(VpnProtocol.AMNEZIA_WG) }
    var selectedDns by remember { mutableStateOf(DnsPreset.DEFAULT) }

    val servers = remember {
        mutableStateListOf(
            ServerNode(
                id = "auto",
                name = "Автовыбор (Оптимальный)",
                countryCode = "AUTO",
                subtitle = "Защищённый канал DanikVpn",
                pingMs = 24,
                protocol = VpnProtocol.AMNEZIA_WG,
                isAuto = true,
                rawConfig = builtInDefaultConfig
            ),
            ServerNode(
                id = "us-main",
                name = "США — Быстрый узел",
                countryCode = "US",
                subtitle = "AmneziaWG 2.0 • Stealth",
                pingMs = 26,
                protocol = VpnProtocol.AMNEZIA_WG,
                rawConfig = builtInDefaultConfig
            )
        )
    }

    var selectedServer by remember { mutableStateOf(servers.first()) }
    var showServerSheet by remember { mutableStateOf(false) }
    val subscriptions = remember { mutableStateListOf<SubscriptionItem>() }

    var connectedSeconds by remember { mutableLongStateOf(0L) }
    var checkedIp by remember { mutableStateOf<String?>(null) }
    var checkedLatency by remember { mutableStateOf<Int?>(null) }
    var isCheckingIp by remember { mutableStateOf(false) }

    LaunchedEffect(connectionState) {
        if (connectionState == ConnectionState.CONNECTED) {
            connectedSeconds = 0L
            while (true) {
                delay(1000L)
                connectedSeconds++
            }
        } else {
            connectedSeconds = 0L
        }
    }

    fun launchConnect() {
        val baseCfg = selectedServer.rawConfig.ifBlank { builtInDefaultConfig }
        val finalCfg = ConfigManager.applyRuntimeOptions(baseCfg, selectedProtocol, selectedDns)
        DanikTunnelManager.connect(context, finalCfg, selectedServer.name)
    }

    val vpnPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            launchConnect()
        } else {
            Toast.makeText(context, "Нужно разрешение Android на создание VPN", Toast.LENGTH_SHORT).show()
        }
    }

    fun toggleConnection() {
        if (connectionState == ConnectionState.CONNECTED || connectionState == ConnectionState.CONNECTING) {
            DanikTunnelManager.disconnect(context)
            checkedIp = null
            checkedLatency = null
        } else {
            val prepareIntent = DanikTunnelManager.prepareVpnIntent(context)
            if (prepareIntent != null) {
                vpnPermissionLauncher.launch(prepareIntent)
            } else {
                launchConnect()
            }
        }
    }

    fun runIpCheck() {
        if (isCheckingIp) return
        isCheckingIp = true
        scope.launch {
            try {
                val (ip, ping) = withContext(Dispatchers.IO) {
                    ConfigManager.checkPublicIpAndPing()
                }
                checkedIp = ip
                checkedLatency = ping
            } catch (_: Exception) {
                checkedIp = "Нет ответа"
                checkedLatency = null
            } finally {
                isCheckingIp = false
            }
        }
    }

    Scaffold(
        containerColor = ObsidianBg,
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 20.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(RoundedCornerShape(13.dp))
                            .background(
                                Brush.linearGradient(listOf(BananaYellow, BananaGold))
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("🍌", fontSize = 21.sp)
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "DanikVpn",
                            color = TextPrimary,
                            fontSize = 21.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Text(
                            text = "AmneziaWG 2.0 • Turbo Core",
                            color = BananaYellow,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(50),
                    color = CardElevated,
                    border = BorderStroke(1.dp, BananaYellow.copy(alpha = 0.45f)),
                    modifier = Modifier.clickable { selectedTab = 1 }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Rounded.VerifiedUser,
                            contentDescription = null,
                            tint = BananaYellow,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = selectedProtocol.badge,
                            color = BananaYellow,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        },
        bottomBar = {
            NavigationBar(
                containerColor = CardDark,
                tonalElevation = 10.dp
            ) {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = { Icon(Icons.Rounded.PowerSettingsNew, contentDescription = "VPN") },
                    label = { Text("VPN") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = ObsidianBg,
                        selectedTextColor = BananaYellow,
                        indicatorColor = BananaYellow,
                        unselectedIconColor = TextSecondary,
                        unselectedTextColor = TextSecondary
                    )
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = { Icon(Icons.Rounded.Tune, contentDescription = "Настройки") },
                    label = { Text("Настройки") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = ObsidianBg,
                        selectedTextColor = BananaYellow,
                        indicatorColor = BananaYellow,
                        unselectedIconColor = TextSecondary,
                        unselectedTextColor = TextSecondary
                    )
                )
            }
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            if (selectedTab == 0) {
                HomeScreen(
                    connectionState = connectionState,
                    connectedSeconds = connectedSeconds,
                    statusLog = statusLog,
                    rxBytes = rxBytes,
                    txBytes = txBytes,
                    rxSpeed = rxSpeed,
                    txSpeed = txSpeed,
                    speedHistory = speedHistory,
                    selectedServer = selectedServer,
                    checkedIp = checkedIp,
                    checkedLatency = checkedLatency,
                    isCheckingIp = isCheckingIp,
                    onToggleConnect = { toggleConnection() },
                    onOpenServerPicker = { showServerSheet = true },
                    onCheckIp = { runIpCheck() }
                )
            } else {
                SettingsScreen(
                    selectedProtocol = selectedProtocol,
                    selectedDns = selectedDns,
                    subscriptions = subscriptions,
                    onProtocolSelect = { selectedProtocol = it },
                    onDnsSelect = { selectedDns = it },
                    onAddSubscription = { subName, subUrl ->
                        scope.launch {
                            try {
                                val loadedServers = withContext(Dispatchers.IO) {
                                    ConfigManager.fetchSubscription(subUrl)
                                }
                                if (loadedServers.isNotEmpty()) {
                                    servers.addAll(loadedServers)
                                    subscriptions.add(
                                        SubscriptionItem(
                                            name = subName.ifBlank { "Подписка" },
                                            url = subUrl,
                                            serverCount = loadedServers.size,
                                            updatedAt = ConfigManager.currentTimeFormatted()
                                        )
                                    )
                                    selectedServer = loadedServers.first()
                                    Toast.makeText(
                                        context,
                                        "Загружено серверов: ${loadedServers.size}",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                } else {
                                    Toast.makeText(context, "Подписка пуста", Toast.LENGTH_SHORT).show()
                                }
                            } catch (e: Exception) {
                                Toast.makeText(
                                    context,
                                    "Ошибка загрузки подписки: ${e.localizedMessage}",
                                    Toast.LENGTH_LONG
                                ).show()
                            }
                        }
                    },
                    onDeleteSubscription = { sub ->
                        subscriptions.remove(sub)
                        servers.removeAll { it.subscriptionSource == sub.url }
                        if (selectedServer.subscriptionSource == sub.url) {
                            selectedServer = servers.first()
                        }
                    }
                )
            }
        }

        if (showServerSheet) {
            ModalBottomSheet(
                onDismissRequest = { showServerSheet = false },
                containerColor = CardDark
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 8.dp)
                ) {
                    Text(
                        text = "Выбор сервера",
                        color = TextPrimary,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "По умолчанию активен автовыбор оптимального узла",
                        color = TextSecondary,
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.height(14.dp))

                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.heightIn(max = 420.dp)
                    ) {
                        items(servers) { server ->
                            val isSelected = server.id == selectedServer.id
                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = if (isSelected) CardElevated else ObsidianBg,
                                border = BorderStroke(
                                    width = if (isSelected) 1.5.dp else 1.dp,
                                    color = if (isSelected) BananaYellow else Color.White.copy(alpha = 0.08f)
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        selectedServer = server
                                        showServerSheet = false
                                        if (connectionState == ConnectionState.CONNECTED) {
                                            launchConnect()
                                        }
                                    }
                            ) {
                                Row(
                                    modifier = Modifier
                                        .padding(14.dp)
                                        .fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier
                                                .size(40.dp)
                                                .clip(CircleShape)
                                                .background(
                                                    if (server.isAuto) BananaYellow.copy(alpha = 0.2f)
                                                    else CardElevated
                                                ),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            if (server.isAuto) {
                                                Icon(
                                                    Icons.Rounded.AutoAwesome,
                                                    contentDescription = null,
                                                    tint = BananaYellow
                                                )
                                            } else {
                                                Text(
                                                    text = server.countryCode,
                                                    color = BananaYellow,
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 12.sp
                                                )
                                            }
                                        }
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Column {
                                            Text(
                                                text = server.name,
                                                color = TextPrimary,
                                                fontWeight = FontWeight.SemiBold,
                                                fontSize = 15.sp
                                            )
                                            Text(
                                                text = "${server.protocol.badge} • ${server.subtitle}",
                                                color = TextSecondary,
                                                fontSize = 12.sp
                                            )
                                        }
                                    }
                                    Text(
                                        text = "${server.pingMs} мс",
                                        color = ConnectedGreen,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp
                                    )
                                }
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(24.dp))
                }
            }
        }
    }
}

@Composable
fun HomeScreen(
    connectionState: ConnectionState,
    connectedSeconds: Long,
    statusLog: String,
    rxBytes: Long,
    txBytes: Long,
    rxSpeed: Long,
    txSpeed: Long,
    speedHistory: List<Float>,
    selectedServer: ServerNode,
    checkedIp: String?,
    checkedLatency: Int?,
    isCheckingIp: Boolean,
    onToggleConnect: () -> Unit,
    onOpenServerPicker: () -> Unit,
    onCheckIp: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "orbital")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.98f,
        targetValue = if (connectionState == ConnectionState.CONNECTED) 1.09f else 1.03f,
        animationSpec = infiniteRepeatable(
            animation = tween(1300, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseScale"
    )
    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = if (connectionState == ConnectionState.CONNECTING) 1400 else 6500,
                easing = LinearEasing
            ),
            repeatMode = RepeatMode.Restart
        ),
        label = "ringRot"
    )

    val accent by animateColorAsState(
        targetValue = when (connectionState) {
            ConnectionState.CONNECTED -> ConnectedGreen
            ConnectionState.CONNECTING -> BananaGold
            ConnectionState.DISCONNECTED -> BananaYellow
        },
        label = "accentColor"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = CardDark,
            border = BorderStroke(1.dp, accent.copy(alpha = 0.25f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(accent)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = when (connectionState) {
                                ConnectionState.CONNECTED -> "Защищено • ${formatDuration(connectedSeconds)}"
                                ConnectionState.CONNECTING -> "Подключение..."
                                ConnectionState.DISCONNECTED -> "Отключено"
                            },
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Text(
                            text = if (checkedIp != null)
                                "IP: $checkedIp" + (checkedLatency?.let { " • $it мс" } ?: "")
                            else statusLog,
                            color = TextSecondary,
                            fontSize = 11.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
                FilledTonalButton(
                    onClick = onCheckIp,
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    colors = ButtonDefaults.filledTonalButtonColors(
                        containerColor = CardElevated,
                        contentColor = BananaYellow
                    ),
                    modifier = Modifier.height(32.dp)
                ) {
                    Text(
                        text = if (isCheckingIp) "..." else "IP / Пинг",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.padding(vertical = 4.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(214.dp)
                    .scale(pulseScale)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(accent.copy(alpha = 0.28f), Color.Transparent)
                        )
                    )
            )

            Canvas(
                modifier = Modifier
                    .size(182.dp)
                    .rotate(rotation)
            ) {
                drawArc(
                    brush = Brush.sweepGradient(
                        listOf(Color.Transparent, accent.copy(alpha = 0.85f), Color.Transparent)
                    ),
                    startAngle = 0f,
                    sweepAngle = 220f,
                    useCenter = false,
                    style = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round)
                )
            }

            Box(
                modifier = Modifier
                    .size(156.dp)
                    .shadow(26.dp, CircleShape)
                    .clip(CircleShape)
                    .background(
                        Brush.verticalGradient(listOf(CardElevated, CardDark))
                    )
                    .border(2.5.dp, accent, CircleShape)
                    .clickable { onToggleConnect() },
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Rounded.PowerSettingsNew,
                        contentDescription = "Кнопка подключения",
                        tint = accent,
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = when (connectionState) {
                            ConnectionState.CONNECTED -> "СТОП"
                            ConnectionState.CONNECTING -> "ЗАПУСК"
                            ConnectionState.DISCONNECTED -> "СТАРТ"
                        },
                        color = accent,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 13.sp,
                        letterSpacing = 1.6.sp
                    )
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            TrafficCard(
                modifier = Modifier.weight(1f),
                title = "Скачивание",
                value = formatBytes(rxBytes),
                speed = "${formatBytes(rxSpeed)}/с",
                icon = Icons.Rounded.ArrowDownward,
                accent = ConnectedGreen
            )
            TrafficCard(
                modifier = Modifier.weight(1f),
                title = "Отдача",
                value = formatBytes(txBytes),
                speed = "${formatBytes(txSpeed)}/с",
                icon = Icons.Rounded.ArrowUpward,
                accent = BananaYellow
            )
        }

        Surface(
            shape = RoundedCornerShape(16.dp),
            color = CardDark,
            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.06f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Активность туннеля", color = TextSecondary, fontSize = 11.sp)
                    Text(
                        text = if (connectionState == ConnectionState.CONNECTED) "LIVE" else "ОЖИДАНИЕ",
                        color = if (connectionState == ConnectionState.CONNECTED) ConnectedGreen else TextSecondary,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                Canvas(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                ) {
                    val maxVal = (speedHistory.maxOrNull() ?: 10f).coerceAtLeast(10f)
                    val stepX = size.width / (speedHistory.size - 1).coerceAtLeast(1)
                    val path = Path()
                    speedHistory.forEachIndexed { idx, v ->
                        val x = idx * stepX
                        val y = size.height - (v / maxVal) * (size.height - 6f) - 3f
                        if (idx == 0) path.moveTo(x, y) else path.lineTo(x, y)
                    }
                    drawPath(
                        path = path,
                        color = accent,
                        style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round)
                    )
                }
            }
        }

        Surface(
            shape = RoundedCornerShape(20.dp),
            color = CardDark,
            border = BorderStroke(1.dp, BananaYellow.copy(alpha = 0.35f)),
            modifier = Modifier
                .fillMaxWidth()
                .clickable { onOpenServerPicker() }
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(BananaYellow.copy(alpha = 0.16f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (selectedServer.isAuto) Icons.Rounded.AutoAwesome else Icons.Rounded.Public,
                            contentDescription = null,
                            tint = BananaYellow
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text("Сервер подключения", color = TextSecondary, fontSize = 11.sp)
                        Text(
                            text = selectedServer.name,
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "${selectedServer.subtitle} • ${selectedServer.pingMs} мс",
                            color = ConnectedGreen,
                            fontSize = 12.sp
                        )
                    }
                }
                Icon(
                    imageVector = Icons.Rounded.KeyboardArrowDown,
                    contentDescription = "Выбрать сервер",
                    tint = BananaYellow
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))
    }
}

@Composable
fun TrafficCard(
    modifier: Modifier = Modifier,
    title: String,
    value: String,
    speed: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    accent: Color
) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = CardDark,
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.06f)),
        modifier = modifier
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(title, color = TextSecondary, fontSize = 11.sp)
                Text(value, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text(speed, color = accent, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    selectedProtocol: VpnProtocol,
    selectedDns: DnsPreset,
    subscriptions: List<SubscriptionItem>,
    onProtocolSelect: (VpnProtocol) -> Unit,
    onDnsSelect: (DnsPreset) -> Unit,
    onAddSubscription: (String, String) -> Unit,
    onDeleteSubscription: (SubscriptionItem) -> Unit
) {
    val clipboard = LocalClipboardManager.current
    var subNameInput by remember { mutableStateOf("Моя подписка") }
    var subUrlInput by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Протокол подключения",
            color = BananaYellow,
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp
        )
        VpnProtocol.entries.forEach { protocol ->
            val selected = protocol == selectedProtocol
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = if (selected) CardElevated else CardDark,
                border = BorderStroke(
                    if (selected) 1.5.dp else 1.dp,
                    if (selected) BananaYellow else Color.White.copy(alpha = 0.08f)
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onProtocolSelect(protocol) }
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(
                        selected = selected,
                        onClick = { onProtocolSelect(protocol) },
                        colors = RadioButtonDefaults.colors(selectedColor = BananaYellow)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(protocol.title, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(protocol.description, color = TextSecondary, fontSize = 12.sp)
                    }
                }
            }
        }

        Text(
            text = "DNS-сервер",
            color = BananaYellow,
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp
        )
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            DnsPreset.entries.take(2).forEach { preset ->
                FilterChip(
                    selected = selectedDns == preset,
                    onClick = { onDnsSelect(preset) },
                    label = { Text(preset.label, fontSize = 12.sp) },
                    modifier = Modifier.weight(1f)
                )
            }
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            DnsPreset.entries.drop(2).forEach { preset ->
                FilterChip(
                    selected = selectedDns == preset,
                    onClick = { onDnsSelect(preset) },
                    label = { Text(preset.label, fontSize = 12.sp) },
                    modifier = Modifier.weight(1f)
                )
            }
        }

        Text(
            text = "Подписки (как в Happ)",
            color = BananaYellow,
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp
        )
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = CardDark,
            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.08f))
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = subNameInput,
                    onValueChange = { subNameInput = it },
                    label = { Text("Название подписки") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = subUrlInput,
                    onValueChange = { subUrlInput = it },
                    label = { Text("Ссылка подписки (https://...)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(
                        onClick = {
                            clipboard.getText()?.text?.let { subUrlInput = it }
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Из буфера", color = TextPrimary)
                    }
                    Button(
                        onClick = {
                            if (subUrlInput.isNotBlank()) {
                                onAddSubscription(subNameInput, subUrlInput)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = BananaYellow),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Загрузить", color = ObsidianBg, fontWeight = FontWeight.Bold)
                    }
                }

                subscriptions.forEach { sub ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(sub.name, color = TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                            Text(
                                "${sub.serverCount} серв. • обн. ${sub.updatedAt}",
                                color = ConnectedGreen,
                                fontSize = 11.sp
                            )
                        }
                        IconButton(onClick = { onDeleteSubscription(sub) }) {
                            Icon(Icons.Rounded.DeleteOutline, contentDescription = "Удалить", tint = DangerRed)
                        }
                    }
                }
            }
        }

        Surface(
            shape = RoundedCornerShape(16.dp),
            color = CardDark,
            border = BorderStroke(1.dp, BananaYellow.copy(alpha = 0.25f))
        ) {
            Row(
                modifier = Modifier.padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Rounded.Lock,
                    contentDescription = null,
                    tint = BananaYellow,
                    modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = "Ключи основного канала зашифрованы внутри приложения и полностью скрыты от просмотра.",
                    color = TextSecondary,
                    fontSize = 12.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}

private fun formatDuration(totalSeconds: Long): String {
    val hrs = totalSeconds / 3600
    val mins = (totalSeconds % 3600) / 60
    val secs = totalSeconds % 60
    return String.format("%02d:%02d:%02d", hrs, mins, secs)
}

private fun formatBytes(bytes: Long): String {
    return when {
        bytes < 1024 -> "$bytes Б"
        bytes < 1024 * 1024 -> String.format("%.1f КБ", bytes / 1024.0)
        bytes < 1024 * 1024 * 1024 -> String.format("%.2f МБ", bytes / (1024.0 * 1024.0))
        else -> String.format("%.2f ГБ", bytes / (1024.0 * 1024.0 * 1024.0))
    }
}
