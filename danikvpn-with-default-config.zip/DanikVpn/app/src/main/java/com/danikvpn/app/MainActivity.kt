package com.danikvpn.app

import android.app.Activity
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.danikvpn.app.data.ConfigParser
import com.danikvpn.app.model.ConnectionState
import com.danikvpn.app.model.ServerNode
import com.danikvpn.app.model.SubscriptionItem
import com.danikvpn.app.model.VpnProtocol
import com.danikvpn.app.ui.theme.*
import com.danikvpn.app.vpn.DanikVpnService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val defaultConfig = try {
            assets.open("default_awg.conf").bufferedReader().use { it.readText() }
        } catch (_: Exception) {
            ""
        }

        setContent {
            DanikVpnTheme {
                DanikVpnApp(builtInDefaultConfig = defaultConfig)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DanikVpnApp(builtInDefaultConfig: String) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val isServiceRunning by DanikVpnService.isRunning.collectAsState()
    val rxBytes by DanikVpnService.rxBytes.collectAsState()
    val txBytes by DanikVpnService.txBytes.collectAsState()
    val lastError by DanikVpnService.lastError.collectAsState()

    LaunchedEffect(lastError) {
        if (!lastError.isNullOrBlank()) {
            Toast.makeText(context, lastError, Toast.LENGTH_LONG).show()
        }
    }

    var selectedTab by remember { mutableIntStateOf(0) }
    var selectedProtocol by remember { mutableStateOf(VpnProtocol.AMNEZIA_WG) }

    val servers = remember {
        mutableStateListOf(
            ServerNode(
                id = "auto",
                name = "Автовыбор (Оптимальный)",
                countryCode = "AUTO",
                subtitle = "Защищённый канал DanikVpn",
                pingMs = 24,
                protocol = VpnProtocol.AMNEZIA_WG,
                isAuto = true,
                rawConfig = builtInDefaultConfig
            ),
            ServerNode(
                id = "us-primary",
                name = "США — Основной сервер",
                countryCode = "US",
                subtitle = "Высокоскоростной узел AWG",
                pingMs = 26,
                protocol = VpnProtocol.AMNEZIA_WG,
                rawConfig = builtInDefaultConfig
            )
        )
    }

    var selectedServer by remember { mutableStateOf(servers.first()) }
    var showServerSheet by remember { mutableStateOf(false) }
    val subscriptions = remember { mutableStateListOf<SubscriptionItem>() }

    var isConnectingTransition by remember { mutableStateOf(false) }
    var connectedSeconds by remember { mutableLongStateOf(0L) }

    val connectionState = when {
        isServiceRunning -> ConnectionState.CONNECTED
        isConnectingTransition -> ConnectionState.CONNECTING
        else -> ConnectionState.DISCONNECTED
    }

    LaunchedEffect(isServiceRunning) {
        if (isServiceRunning) {
            isConnectingTransition = false
            connectedSeconds = 0L
            while (true) {
                delay(1000L)
                connectedSeconds++
            }
        } else {
            connectedSeconds = 0L
        }
    }

    fun startVpnService() {
        val configToUse = selectedServer.rawConfig.ifBlank { builtInDefaultConfig }
        val intent = Intent(context, DanikVpnService::class.java).apply {
            action = DanikVpnService.ACTION_CONNECT
            putExtra(DanikVpnService.EXTRA_CONFIG, configToUse)
            putExtra(DanikVpnService.EXTRA_SERVER_NAME, selectedServer.name)
            putExtra(DanikVpnService.EXTRA_PROTOCOL, selectedProtocol.badge)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(intent)
        } else {
            context.startService(intent)
        }
    }

    val vpnPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            startVpnService()
        } else {
            isConnectingTransition = false
            Toast.makeText(context, "Разрешение VPN отклонено", Toast.LENGTH_SHORT).show()
        }
    }

    fun toggleConnection() {
        if (connectionState == ConnectionState.CONNECTED || connectionState == ConnectionState.CONNECTING) {
            isConnectingTransition = false
            val stopIntent = Intent(context, DanikVpnService::class.java).apply {
                action = DanikVpnService.ACTION_DISCONNECT
            }
            context.startService(stopIntent)
        } else {
            isConnectingTransition = true
            val prepareIntent = VpnService.prepare(context)
            if (prepareIntent != null) {
                vpnPermissionLauncher.launch(prepareIntent)
            } else {
                startVpnService()
            }
        }
    }

    Scaffold(
        containerColor = ObsidianBg,
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 20.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(BananaYellow),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("🍌", fontSize = 20.sp)
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "DanikVpn",
                            color = TextPrimary,
                            fontSize = 21.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Text(
                            text = "AmneziaWG Stealth Engine",
                            color = BananaYellow,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(50),
                    color = CardElevated,
                    border = BorderStroke(1.dp, BananaYellow.copy(alpha = 0.4f)),
                    modifier = Modifier.clickable { selectedTab = 1 }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Rounded.Shield,
                            contentDescription = null,
                            tint = BananaYellow,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = selectedProtocol.badge,
                            color = BananaYellow,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        },
        bottomBar = {
            NavigationBar(
                containerColor = CardDark,
                tonalElevation = 8.dp
            ) {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = { Icon(Icons.Rounded.PowerSettingsNew, contentDescription = "VPN") },
                    label = { Text("Подключение") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = ObsidianBg,
                        selectedTextColor = BananaYellow,
                        indicatorColor = BananaYellow,
                        unselectedIconColor = TextSecondary,
                        unselectedTextColor = TextSecondary
                    )
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = { Icon(Icons.Rounded.Tune, contentDescription = "Настройки") },
                    label = { Text("Настройки") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = ObsidianBg,
                        selectedTextColor = BananaYellow,
                        indicatorColor = BananaYellow,
                        unselectedIconColor = TextSecondary,
                        unselectedTextColor = TextSecondary
                    )
                )
            }
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            if (selectedTab == 0) {
                HomeScreen(
                    connectionState = connectionState,
                    connectedSeconds = connectedSeconds,
                    rxBytes = rxBytes,
                    txBytes = txBytes,
                    selectedServer = selectedServer,
                    selectedProtocol = selectedProtocol,
                    onToggleConnect = { toggleConnection() },
                    onOpenServerPicker = { showServerSheet = true },
                    onQuickAddSubscription = { selectedTab = 1 }
                )
            } else {
                SettingsScreen(
                    selectedProtocol = selectedProtocol,
                    subscriptions = subscriptions,
                    onProtocolSelect = { selectedProtocol = it },
                    onAddSubscription = { subName, subUrl ->
                        scope.launch {
                            try {
                                val loadedServers = withContext(Dispatchers.IO) {
                                    ConfigParser.fetchSubscription(subUrl)
                                }
                                if (loadedServers.isNotEmpty()) {
                                    servers.addAll(loadedServers)
                                    subscriptions.add(
                                        SubscriptionItem(
                                            name = subName.ifBlank { "Подписка" },
                                            url = subUrl,
                                            serverCount = loadedServers.size,
                                            updatedAt = ConfigParser.currentTimeFormatted()
                                        )
                                    )
                                    selectedServer = loadedServers.first()
                                    Toast.makeText(
                                        context,
                                        "Загружено серверов: ${loadedServers.size}",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                } else {
                                    Toast.makeText(context, "Подписка пуста", Toast.LENGTH_SHORT).show()
                                }
                            } catch (e: Exception) {
                                Toast.makeText(
                                    context,
                                    "Ошибка загрузки подписки: ${e.localizedMessage}",
                                    Toast.LENGTH_LONG
                                ).show()
                            }
                        }
                    }
                )
            }
        }

        if (showServerSheet) {
            ModalBottomSheet(
                onDismissRequest = { showServerSheet = false },
                containerColor = CardDark
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 8.dp)
                ) {
                    Text(
                        text = "Выбор сервера",
                        color = TextPrimary,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "По умолчанию активен автовыбор оптимального узла",
                        color = TextSecondary,
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.height(14.dp))

                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.heightIn(max = 420.dp)
                    ) {
                        items(servers) { server ->
                            val isSelected = server.id == selectedServer.id
                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = if (isSelected) CardElevated else ObsidianBg,
                                border = BorderStroke(
                                    width = if (isSelected) 1.5.dp else 1.dp,
                                    color = if (isSelected) BananaYellow else Color.White.copy(alpha = 0.08f)
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        selectedServer = server
                                        showServerSheet = false
                                    }
                            ) {
                                Row(
                                    modifier = Modifier
                                        .padding(14.dp)
                                        .fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier
                                                .size(40.dp)
                                                .clip(CircleShape)
                                                .background(
                                                    if (server.isAuto) BananaYellow.copy(alpha = 0.2f)
                                                    else CardElevated
                                                ),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            if (server.isAuto) {
                                                Icon(
                                                    Icons.Rounded.AutoAwesome,
                                                    contentDescription = null,
                                                    tint = BananaYellow
                                                )
                                            } else {
                                                Text(
                                                    text = server.countryCode,
                                                    color = BananaYellow,
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 12.sp
                                                )
                                            }
                                        }
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Column {
                                            Text(
                                                text = server.name,
                                                color = TextPrimary,
                                                fontWeight = FontWeight.SemiBold,
                                                fontSize = 15.sp
                                            )
                                            Text(
                                                text = "${server.protocol.badge} • ${server.subtitle}",
                                                color = TextSecondary,
                                                fontSize = 12.sp
                                            )
                                        }
                                    }
                                    Text(
                                        text = "${server.pingMs} мс",
                                        color = ConnectedGreen,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp
                                    )
                                }
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(24.dp))
                }
            }
        }
    }
}

@Composable
fun HomeScreen(
    connectionState: ConnectionState,
    connectedSeconds: Long,
    rxBytes: Long,
    txBytes: Long,
    selectedServer: ServerNode,
    selectedProtocol: VpnProtocol,
    onToggleConnect: () -> Unit,
    onOpenServerPicker: () -> Unit,
    onQuickAddSubscription: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = if (connectionState == ConnectionState.CONNECTED) 1.08f else 1.02f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseScale"
    )

    val buttonAccent by animateColorAsState(
        targetValue = when (connectionState) {
            ConnectionState.CONNECTED -> ConnectedGreen
            ConnectionState.CONNECTING -> BananaGold
            ConnectionState.DISCONNECTED -> BananaYellow
        },
        label = "btnColor"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = CardDark,
            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.06f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(buttonAccent)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = when (connectionState) {
                                ConnectionState.CONNECTED -> "Защищено • DanikVpn"
                                ConnectionState.CONNECTING -> "Установка туннеля..."
                                ConnectionState.DISCONNECTED -> "Отключено"
                            },
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                        Text(
                            text = if (connectionState == ConnectionState.CONNECTED)
                                "Время сессии: ${formatDuration(connectedSeconds)}"
                            else "Нажмите кнопку питания для подключения",
                            color = TextSecondary,
                            fontSize = 12.sp
                        )
                    }
                }
                Text(
                    text = selectedProtocol.badge,
                    color = BananaYellow,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 13.sp
                )
            }
        }

        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.padding(vertical = 12.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(216.dp)
                    .scale(pulseScale)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                buttonAccent.copy(alpha = 0.25f),
                                Color.Transparent
                            )
                        )
                    )
            )

            Box(
                modifier = Modifier
                    .size(164.dp)
                    .shadow(24.dp, CircleShape)
                    .clip(CircleShape)
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(CardElevated, CardDark)
                        )
                    )
                    .border(3.dp, buttonAccent, CircleShape)
                    .clickable { onToggleConnect() },
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Rounded.PowerSettingsNew,
                        contentDescription = "Кнопка подключения",
                        tint = buttonAccent,
                        modifier = Modifier.size(68.dp)
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = when (connectionState) {
                            ConnectionState.CONNECTED -> "СТОП"
                            ConnectionState.CONNECTING -> "..."
                            ConnectionState.DISCONNECTED -> "СТАРТ"
                        },
                        color = buttonAccent,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 13.sp,
                        letterSpacing = 1.5.sp
                    )
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            TrafficCard(
                modifier = Modifier.weight(1f),
                title = "Скачивание",
                value = formatBytes(rxBytes),
                icon = Icons.Rounded.ArrowDownward,
                accent = ConnectedGreen
            )
            TrafficCard(
                modifier = Modifier.weight(1f),
                title = "Отдача",
                value = formatBytes(txBytes),
                icon = Icons.Rounded.ArrowUpward,
                accent = BananaYellow
            )
        }

        Column(modifier = Modifier.padding(bottom = 14.dp)) {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = CardDark,
                border = BorderStroke(1.dp, BananaYellow.copy(alpha = 0.35f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onOpenServerPicker() }
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .background(BananaYellow.copy(alpha = 0.16f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (selectedServer.isAuto) Icons.Rounded.AutoAwesome else Icons.Rounded.Public,
                                contentDescription = null,
                                tint = BananaYellow
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Сервер подключения",
                                color = TextSecondary,
                                fontSize = 11.sp
                            )
                            Text(
                                text = selectedServer.name,
                                color = TextPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "${selectedServer.subtitle} • ${selectedServer.pingMs} мс",
                                color = ConnectedGreen,
                                fontSize = 12.sp
                            )
                        }
                    }
                    Icon(
                        imageVector = Icons.Rounded.KeyboardArrowDown,
                        contentDescription = "Выбрать сервер",
                        tint = BananaYellow
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedButton(
                onClick = onQuickAddSubscription,
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.14f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Rounded.AddLink, contentDescription = null, tint = BananaYellow, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Добавить свою подписку (как в Happ)",
                    color = TextPrimary,
                    fontSize = 13.sp
                )
            }
        }
    }
}

@Composable
fun TrafficCard(
    modifier: Modifier = Modifier,
    title: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    accent: Color
) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = CardDark,
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.06f)),
        modifier = modifier
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(title, color = TextSecondary, fontSize = 11.sp)
                Text(value, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
        }
    }
}

@Composable
fun SettingsScreen(
    selectedProtocol: VpnProtocol,
    subscriptions: List<SubscriptionItem>,
    onProtocolSelect: (VpnProtocol) -> Unit,
    onAddSubscription: (String, String) -> Unit
) {
    val clipboard = LocalClipboardManager.current
    var subNameInput by remember { mutableStateOf("Моя подписка") }
    var subUrlInput by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Protocol Switcher
        Text(
            text = "Протокол подключения",
            color = BananaYellow,
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp
        )
        VpnProtocol.entries.forEach { protocol ->
            val selected = protocol == selectedProtocol
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = if (selected) CardElevated else CardDark,
                border = BorderStroke(
                    if (selected) 1.5.dp else 1.dp,
                    if (selected) BananaYellow else Color.White.copy(alpha = 0.08f)
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onProtocolSelect(protocol) }
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(
                        selected = selected,
                        onClick = { onProtocolSelect(protocol) },
                        colors = RadioButtonDefaults.colors(selectedColor = BananaYellow)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(protocol.title, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(protocol.description, color = TextSecondary, fontSize = 12.sp)
                    }
                }
            }
        }

        // 2. Subscriptions (like Happ) — without exposing built-in AmneziaWG config
        Text(
            text = "Добавить подписку (как в Happ)",
            color = BananaYellow,
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp
        )
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = CardDark,
            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.08f))
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = subNameInput,
                    onValueChange = { subNameInput = it },
                    label = { Text("Название подписки") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = subUrlInput,
                    onValueChange = { subUrlInput = it },
                    label = { Text("Ссылка подписки (https://...)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(
                        onClick = {
                            clipboard.getText()?.text?.let { subUrlInput = it }
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Из буфера", color = TextPrimary)
                    }
                    Button(
                        onClick = {
                            if (subUrlInput.isNotBlank()) {
                                onAddSubscription(subNameInput, subUrlInput)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = BananaYellow),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Загрузить", color = ObsidianBg, fontWeight = FontWeight.Bold)
                    }
                }

                subscriptions.forEach { sub ->
                    Text(
                        text = "• ${sub.name}: ${sub.serverCount} серв. (обн. ${sub.updatedAt})",
                        color = ConnectedGreen,
                        fontSize = 12.sp
                    )
                }
            }
        }

        // 3. Security Info Card
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = CardDark,
            border = BorderStroke(1.dp, BananaYellow.copy(alpha = 0.25f))
        ) {
            Row(
                modifier = Modifier.padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Rounded.Lock,
                    contentDescription = null,
                    tint = BananaYellow,
                    modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = "Конфигурация основного канала зашита внутри приложения и скрыта от просмотра.",
                    color = TextSecondary,
                    fontSize = 12.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}

private fun formatDuration(totalSeconds: Long): String {
    val hrs = totalSeconds / 3600
    val mins = (totalSeconds % 3600) / 60
    val secs = totalSeconds % 60
    return String.format("%02d:%02d:%02d", hrs, mins, secs)
}

private fun formatBytes(bytes: Long): String {
    return when {
        bytes < 1024 -> "$bytes Б"
        bytes < 1024 * 1024 -> String.format("%.1f КБ", bytes / 1024.0)
        bytes < 1024 * 1024 * 1024 -> String.format("%.2f МБ", bytes / (1024.0 * 1024.0))
        else -> String.format("%.2f ГБ", bytes / (1024.0 * 1024.0 * 1024.0))
    }
}
