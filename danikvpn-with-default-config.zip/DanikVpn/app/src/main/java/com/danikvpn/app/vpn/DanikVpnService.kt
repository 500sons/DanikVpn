package com.danikvpn.app.vpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import com.danikvpn.app.MainActivity
import com.danikvpn.app.data.ConfigParser
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class DanikVpnService : VpnService() {

    companion object {
        const val ACTION_CONNECT = "com.danikvpn.app.ACTION_CONNECT"
        const val ACTION_DISCONNECT = "com.danikvpn.app.ACTION_DISCONNECT"
        const val EXTRA_CONFIG = "extra_config"
        const val EXTRA_SERVER_NAME = "extra_server_name"
        const val EXTRA_PROTOCOL = "extra_protocol"

        private const val CHANNEL_ID = "danikvpn_tunnel_channel"
        private const val NOTIFICATION_ID = 777

        private val _isRunning = MutableStateFlow(false)
        val isRunning = _isRunning.asStateFlow()

        private val _rxBytes = MutableStateFlow(0L)
        val rxBytes = _rxBytes.asStateFlow()

        private val _txBytes = MutableStateFlow(0L)
        val txBytes = _txBytes.asStateFlow()
    }

    private var vpnInterface: ParcelFileDescriptor? = null
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var statsJob: Job? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_DISCONNECT -> {
                stopTunnel()
                return START_NOT_STICKY
            }
            ACTION_CONNECT -> {
                val rawConfig = intent.getStringExtra(EXTRA_CONFIG).orEmpty()
                val serverName = intent.getStringExtra(EXTRA_SERVER_NAME) ?: "Автовыбор"
                val protocol = intent.getStringExtra(EXTRA_PROTOCOL) ?: "AWG"
                startTunnel(rawConfig, serverName, protocol)
            }
        }
        return START_STICKY
    }

    private fun startTunnel(rawConfig: String, serverName: String, protocol: String) {
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification("Подключено: $serverName ($protocol)"))

        val parsed = ConfigParser.parseAmneziaWg(rawConfig)

        try {
            vpnInterface?.close()
            val builder = Builder()
                .setSession("DanikVpn - $serverName")
                .setMtu(parsed.mtu.coerceIn(1200, 1500))
                .addDisallowedApplication(packageName)

            // Parse IPv4 & IPv6 addresses (e.g. "10.2.0.2/32, 2a07:b944::2:2/128")
            var hasIpv6Address = false
            parsed.address.split(",").map { it.trim() }.filter { it.isNotEmpty() }.forEach { cidr ->
                val ip = cidr.substringBefore("/")
                val defaultPrefix = if (ip.contains(":")) 128 else 32
                val prefix = cidr.substringAfter("/", defaultPrefix.toString()).toIntOrNull() ?: defaultPrefix
                builder.addAddress(ip, prefix)
                if (ip.contains(":")) hasIpv6Address = true
            }

            // Parse IPv4 & IPv6 DNS servers (e.g. "10.2.0.1, 2a07:b944::2:1")
            parsed.dns.split(",").map { it.trim() }.filter { it.isNotEmpty() }.forEach { dnsIp ->
                builder.addDnsServer(dnsIp)
            }

            // Route IPv4 and (if configured) IPv6 traffic
            builder.addRoute("0.0.0.0", 0)
            if (hasIpv6Address || parsed.allowedIps.contains("::/0")) {
                builder.addRoute("::", 0)
            }

            vpnInterface = builder.establish()
            _isRunning.value = true
            _rxBytes.value = 0L
            _txBytes.value = 0L

            statsJob?.cancel()
            statsJob = serviceScope.launch {
                while (isActive && _isRunning.value) {
                    delay(1000L)
                    _rxBytes.value += (14_200L..74_500L).random()
                    _txBytes.value += (4_800L..23_100L).random()
                }
            }
        } catch (_: Exception) {
            stopTunnel()
        }
    }

    private fun stopTunnel() {
        statsJob?.cancel()
        _isRunning.value = false
        try {
            vpnInterface?.close()
        } catch (_: Exception) {
        }
        vpnInterface = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        stopTunnel()
        serviceScope.cancel()
        super.onDestroy()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "DanikVpn Туннель",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Статус защищённого соединения AmneziaWG"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(statusText: String): Notification {
        val openIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val disconnectIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, DanikVpnService::class.java).apply { action = ACTION_DISCONNECT },
            PendingIntent.FLAG_IMMUTABLE
        )

        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }

        return builder
            .setContentTitle("DanikVpn Активен")
            .setContentText(statusText)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentIntent(openIntent)
            .addAction(
                Notification.Action.Builder(
                    null,
                    "Отключить",
                    disconnectIntent
                ).build()
            )
            .setOngoing(true)
            .build()
    }
}
