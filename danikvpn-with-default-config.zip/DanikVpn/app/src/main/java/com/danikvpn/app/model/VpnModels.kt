package com.danikvpn.app.model

import java.util.UUID

enum class VpnProtocol(
    val title: String,
    val badge: String,
    val description: String
) {
    AMNEZIA_WG(
        title = "AmneziaWG 2.0 (AWG)",
        badge = "AWG",
        description = "Защищённый протокол с обфускацией трафика для обхода блокировок"
    ),
    WIREGUARD(
        title = "WireGuard",
        badge = "WG",
        description = "Классический высокоскоростной режим WireGuard"
    ),
    VLESS_REALITY(
        title = "VLESS + Reality",
        badge = "VLESS",
        description = "Маскировка трафика под TLS 1.3"
    ),
    AUTO_PROTOCOL(
        title = "Авто-выбор протокола",
        badge = "AUTO",
        description = "Автоматическое определение протокола по профилю сервера"
    )
}

data class AmneziaWgConfig(
    val serverLabel: String = "",
    val privateKey: String = "",
    val address: String = "10.2.0.2/32, 2a07:b944::2:2/128",
    val dns: String = "10.2.0.1, 2a07:b944::2:1",
    val mtu: Int = 1420,
    val jc: Int = 3,
    val jmin: Int = 1,
    val jmax: Int = 3,
    val s1: Int = 0,
    val s2: Int = 0,
    val s3: Int = 0,
    val s4: Int = 0,
    val h1: String = "1",
    val h2: String = "2",
    val h3: String = "3",
    val h4: String = "4",
    val i1: String = "",
    val i2: String = "",
    val i3: String = "",
    val i4: String = "",
    val i5: String = "",
    val publicKey: String = "",
    val presharedKey: String = "",
    val endpoint: String = "",
    val allowedIps: String = "0.0.0.0/0, ::/0",
    val persistentKeepalive: Int = 25,
    val rawText: String = ""
)

data class ServerNode(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val countryCode: String,
    val subtitle: String,
    val pingMs: Int,
    val protocol: VpnProtocol = VpnProtocol.AMNEZIA_WG,
    val isAuto: Boolean = false,
    val rawConfig: String = "",
    val subscriptionSource: String? = null
)

data class SubscriptionItem(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val url: String,
    val serverCount: Int,
    val updatedAt: String
)

enum class ConnectionState {
    DISCONNECTED,
    CONNECTING,
    CONNECTED
}
