package com.danikvpn.app.model

import java.util.UUID

enum class VpnProtocol(
    val title: String,
    val badge: String,
    val description: String
) {
    AMNEZIA_WG(
        title = "AmneziaWG 2.0 (AWG)",
        badge = "AWG 2.0",
        description = "Обфускация заголовков, S1–S4 и CPS-пакет I1 для стабильного обхода DPI"
    ),
    WIREGUARD(
        title = "WireGuard Classic",
        badge = "WG",
        description = "Стандартный протокол WireGuard без дополнительной обфускации"
    ),
    AUTO_PROTOCOL(
        title = "Авто-протокол",
        badge = "AUTO",
        description = "Автоматический подбор оптимального режима туннеля"
    )
}

enum class DnsPreset(val label: String, val servers: String?) {
    DEFAULT("Авто (из канала)", null),
    CLOUDFLARE("Cloudflare 1.1.1.1", "1.1.1.1, 1.0.0.1"),
    GOOGLE("Google 8.8.8.8", "8.8.8.8, 8.8.4.4"),
    ADGUARD("AdGuard (без рекламы)", "94.140.14.14, 94.140.15.15")
}

data class ServerNode(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val countryCode: String,
    val subtitle: String,
    val pingMs: Int,
    val protocol: VpnProtocol = VpnProtocol.AMNEZIA_WG,
    val isAuto: Boolean = false,
    val rawConfig: String = "",
    val subscriptionSource: String? = null
)

data class SubscriptionItem(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val url: String,
    val serverCount: Int,
    val updatedAt: String
)

enum class ConnectionState {
    DISCONNECTED,
    CONNECTING,
    CONNECTED
}
