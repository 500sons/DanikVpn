package com.danikvpn.app.data

import android.content.Context
import android.util.Base64
import com.danikvpn.app.model.DnsPreset
import com.danikvpn.app.model.ServerNode
import com.danikvpn.app.model.VpnProtocol
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

object ConfigManager {

    private val XOR_KEY = "DanikVpnBananaShield2026".toByteArray(Charsets.UTF_8)

    fun loadHiddenDefaultConfig(context: Context): String {
        return try {
            val encrypted = context.assets.open("core_profile.dat").use { it.readBytes() }
            val decrypted = ByteArray(encrypted.size) { i ->
                (encrypted[i].toInt() xor XOR_KEY[i % XOR_KEY.size].toInt()).toByte()
            }
            String(decrypted, Charsets.UTF_8)
        } catch (_: Exception) {
            ""
        }
    }

    fun applyRuntimeOptions(
        rawConfig: String,
        protocol: VpnProtocol,
        dnsPreset: DnsPreset
    ): String {
        val awgKeys = setOf("jc", "jmin", "jmax", "s1", "s2", "s3", "s4", "h1", "h2", "h3", "h4", "i1", "i2", "i3", "i4", "i5")
        val stripAwg = protocol == VpnProtocol.WIREGUARD
        val outLines = mutableListOf<String>()
        var dnsReplaced = false

        rawConfig.lines().forEach { line ->
            val trimmed = line.trim()
            if (trimmed.contains("=") && !trimmed.startsWith("#")) {
                val key = trimmed.substringBefore("=").trim().lowercase()
                if (stripAwg && key in awgKeys) {
                    return@forEach
                }
                if (key == "dns" && dnsPreset.servers != null) {
                    outLines.add("DNS = ${dnsPreset.servers}")
                    dnsReplaced = true
                    return@forEach
                }
            }
            outLines.add(line)
        }

        if (!dnsReplaced && dnsPreset.servers != null) {
            val ifaceIdx = outLines.indexOfFirst { it.trim().equals("[Interface]", ignoreCase = true) }
            if (ifaceIdx >= 0) {
                outLines.add(ifaceIdx + 1, "DNS = ${dnsPreset.servers}")
            }
        }
        return outLines.joinToString("
")
    }

    fun fetchSubscription(subUrl: String): List<ServerNode> {
        val connection = (URL(subUrl.trim()).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 8000
            readTimeout = 8000
            setRequestProperty("User-Agent", "DanikVpn/2.0 (HappCompatible)")
        }

        val body = connection.inputStream.bufferedReader().use { it.readText() }.trim()
        connection.disconnect()

        val decoded = if (body.contains("[Interface]") || body.contains("://")) {
            body
        } else {
            tryDecodeBase64(body)
        }

        val result = mutableListOf<ServerNode>()
        if (decoded.contains("[Interface]")) {
            result.add(
                ServerNode(
                    name = "Сервер подписки (AWG)",
                    countryCode = "SUB",
                    subtitle = "Загружен из подписки",
                    pingMs = Random.nextInt(22, 49),
                    protocol = VpnProtocol.AMNEZIA_WG,
                    rawConfig = decoded,
                    subscriptionSource = subUrl
                )
            )
        } else {
            decoded.lines()
                .map { it.trim() }
                .filter { it.isNotEmpty() && !it.startsWith("#") }
                .forEachIndexed { index, line ->
                    val cfgText = if (line.startsWith("awg://", ignoreCase = true)) {
                        tryDecodeBase64(line.removePrefix("awg://").substringBefore("#"))
                    } else {
                        line
                    }
                    val label = line.substringAfter("#", "Сервер #${index + 1}").ifBlank { "Сервер #${index + 1}" }
                    result.add(
                        ServerNode(
                            name = try { java.net.URLDecoder.decode(label, "UTF-8") } catch (_: Exception) { label },
                            countryCode = "SUB",
                            subtitle = "Узел из подписки",
                            pingMs = Random.nextInt(24, 58),
                            protocol = VpnProtocol.AMNEZIA_WG,
                            rawConfig = cfgText,
                            subscriptionSource = subUrl
                        )
                    )
                }
        }
        return result
    }

    fun checkPublicIpAndPing(): Pair<String, Int> {
        val start = System.currentTimeMillis()
        val conn = (URL("https://api.ipify.org").openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 5000
            readTimeout = 5000
        }
        val ip = conn.inputStream.bufferedReader().use { it.readText() }.trim()
        conn.disconnect()
        val latency = (System.currentTimeMillis() - start).toInt().coerceAtLeast(1)
        return ip to latency
    }

    fun currentTimeFormatted(): String {
        return SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(Date())
    }

    private fun tryDecodeBase64(input: String): String {
        return try {
            val normalized = input.replace('-', '+').replace('_', '/')
            String(Base64.decode(normalized, Base64.DEFAULT), Charsets.UTF_8)
        } catch (_: Exception) {
            input
        }
    }
}
