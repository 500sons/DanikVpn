package com.danikvpn.app.vpn

import android.util.Base64
import com.danikvpn.app.model.AmneziaWgConfig
import java.net.InetAddress

object AwgNativeEngine {

    init {
        System.loadLibrary("wg-go")
        System.loadLibrary("awg_jni")
    }

    external fun wgTurnOn(ifName: String, tunFd: Int, settings: String): Int
    external fun wgTurnOff(handle: Int)
    external fun wgGetSocketV4(handle: Int): Int
    external fun wgGetSocketV6(handle: Int): Int
    external fun wgGetConfig(handle: Int): String?
    external fun wgBumpSockets(handle: Int)
    external fun wgVersion(): String

    fun base64KeyToHex(base64Key: String): String {
        val bytes = Base64.decode(base64Key.trim(), Base64.DEFAULT)
        return bytes.joinToString("") { "%02x".format(it) }
    }

    fun buildUapiConfig(cfg: AmneziaWgConfig, stripObfuscation: Boolean = false): String {
        val sb = StringBuilder()
        val privHex = base64KeyToHex(cfg.privateKey)
        sb.append("private_key=").append(privHex).append('
')
        sb.append("listen_port=0
")

        if (!stripObfuscation) {
            sb.append("jc=").append(cfg.jc).append('
')
            sb.append("jmin=").append(cfg.jmin).append('
')
            sb.append("jmax=").append(cfg.jmax).append('
')
            sb.append("s1=").append(cfg.s1).append('
')
            sb.append("s2=").append(cfg.s2).append('
')
            sb.append("s3=").append(cfg.s3).append('
')
            sb.append("s4=").append(cfg.s4).append('
')
            if (cfg.h1.isNotBlank()) sb.append("h1=").append(cfg.h1).append('
')
            if (cfg.h2.isNotBlank()) sb.append("h2=").append(cfg.h2).append('
')
            if (cfg.h3.isNotBlank()) sb.append("h3=").append(cfg.h3).append('
')
            if (cfg.h4.isNotBlank()) sb.append("h4=").append(cfg.h4).append('
')
            if (cfg.i1.isNotBlank()) sb.append("i1=").append(cfg.i1).append('
')
            if (cfg.i2.isNotBlank()) sb.append("i2=").append(cfg.i2).append('
')
            if (cfg.i3.isNotBlank()) sb.append("i3=").append(cfg.i3).append('
')
            if (cfg.i4.isNotBlank()) sb.append("i4=").append(cfg.i4).append('
')
            if (cfg.i5.isNotBlank()) sb.append("i5=").append(cfg.i5).append('
')
        }

        val pubHex = base64KeyToHex(cfg.publicKey)
        sb.append("public_key=").append(pubHex).append('
')

        if (cfg.presharedKey.isNotBlank()) {
            sb.append("preshared_key=").append(base64KeyToHex(cfg.presharedKey)).append('
')
        }

        val resolvedEndpoint = resolveEndpoint(cfg.endpoint)
        if (resolvedEndpoint.isNotBlank()) {
            sb.append("endpoint=").append(resolvedEndpoint).append('
')
        }

        sb.append("replace_allowed_ips=true
")
        cfg.allowedIps.split(",")
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .forEach { cidr ->
                sb.append("allowed_ip=").append(cidr).append('
')
            }

        if (cfg.persistentKeepalive > 0) {
            sb.append("persistent_keepalive_interval=").append(cfg.persistentKeepalive).append('
')
        }

        sb.append('
')
        return sb.toString()
    }

    private fun resolveEndpoint(endpoint: String): String {
        val clean = endpoint.trim()
        if (clean.isEmpty()) return ""
        val lastColon = clean.lastIndexOf(':')
        if (lastColon <= 0) return clean
        val host = clean.substring(0, lastColon).removePrefix("[").removeSuffix("]")
        val port = clean.substring(lastColon + 1)
        return try {
            val ip = InetAddress.getByName(host).hostAddress ?: host
            if (ip.contains(":")) "[$ip]:$port" else "$ip:$port"
        } catch (_: Exception) {
            clean
        }
    }

    fun parseTrafficStats(uapiOutput: String?): Pair<Long, Long> {
        if (uapiOutput.isNullOrBlank()) return 0L to 0L
        var rx = 0L
        var tx = 0L
        uapiOutput.lines().forEach { line ->
            when {
                line.startsWith("rx_bytes=") -> rx += line.substringAfter("=").trim().toLongOrNull() ?: 0L
                line.startsWith("tx_bytes=") -> tx += line.substringAfter("=").trim().toLongOrNull() ?: 0L
            }
        }
        return rx to tx
    }
}
