#include <jni.h>
#include <stdlib.h>
#include <stdint.h>
#include "libwg-go.h"

JNIEXPORT jint JNICALL
Java_com_danikvpn_app_vpn_AwgNativeEngine_wgTurnOn(
        JNIEnv *env,
        jobject thiz,
        jstring if_name,
        jint tun_fd,
        jstring settings) {
    const char *c_if_name = (*env)->GetStringUTFChars(env, if_name, NULL);
    const char *c_settings = (*env)->GetStringUTFChars(env, settings, NULL);

    int handle = wgTurnOn((char *)c_if_name, (int32_t)tun_fd, (char *)c_settings);

    (*env)->ReleaseStringUTFChars(env, if_name, c_if_name);
    (*env)->ReleaseStringUTFChars(env, settings, c_settings);
    return (jint)handle;
}

JNIEXPORT void JNICALL
Java_com_danikvpn_app_vpn_AwgNativeEngine_wgTurnOff(
        JNIEnv *env,
        jobject thiz,
        jint handle) {
    wgTurnOff((int)handle);
}

JNIEXPORT jint JNICALL
Java_com_danikvpn_app_vpn_AwgNativeEngine_wgGetSocketV4(
        JNIEnv *env,
        jobject thiz,
        jint handle) {
    return (jint)wgGetSocketV4((int)handle);
}

JNIEXPORT jint JNICALL
Java_com_danikvpn_app_vpn_AwgNativeEngine_wgGetSocketV6(
        JNIEnv *env,
        jobject thiz,
        jint handle) {
    return (jint)wgGetSocketV6((int)handle);
}

JNIEXPORT jstring JNICALL
Java_com_danikvpn_app_vpn_AwgNativeEngine_wgGetConfig(
        JNIEnv *env,
        jobject thiz,
        jint handle) {
    char *cfg = wgGetConfig((int)handle);
    if (cfg == NULL) {
        return NULL;
    }
    jstring result = (*env)->NewStringUTF(env, cfg);
    free(cfg);
    return result;
}

JNIEXPORT void JNICALL
Java_com_danikvpn_app_vpn_AwgNativeEngine_wgBumpSockets(
        JNIEnv *env,
        jobject thiz,
        jint handle) {
    wgBumpSockets((int)handle);
}

JNIEXPORT jstring JNICALL
Java_com_danikvpn_app_vpn_AwgNativeEngine_wgVersion(
        JNIEnv *env,
        jobject thiz) {
    const char *ver = wgVersion();
    if (ver == NULL) return (*env)->NewStringUTF(env, "unknown");
    return (*env)->NewStringUTF(env, ver);
}
