cmake_minimum_required(VERSION 3.22.1)
project(awg_jni C)

add_library(wg-go SHARED IMPORTED)
set_target_properties(wg-go PROPERTIES
    IMPORTED_LOCATION "${CMAKE_CURRENT_SOURCE_DIR}/../jniLibs/${ANDROID_ABI}/libwg-go.so"
)

add_library(awg_jni SHARED awg_jni.c)
target_include_directories(awg_jni PRIVATE "${CMAKE_CURRENT_SOURCE_DIR}")
target_link_libraries(awg_jni wg-go log)
